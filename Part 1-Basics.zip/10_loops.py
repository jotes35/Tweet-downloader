# iterating using for loop

string='Python'
for i in string:
    print(i)

mylist=range(5)
for i in mylist:
    print(i)
