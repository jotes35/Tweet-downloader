#eg.1 adding strings
#string1='hello'
#string2='world'
#string3=string1+string2
#print(string3)


#eg. 2 find the length of a string
#string='Hello World'
#length=len(string)
#print(length)

