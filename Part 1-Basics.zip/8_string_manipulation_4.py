string='Python'

#print(string.upper())
#print(string.lower())


