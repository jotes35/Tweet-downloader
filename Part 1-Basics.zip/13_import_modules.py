
#import module 
import matplotlib.pyplot as plt





def plot():
    plt.plot([1,2,3])
    plt.show()


plot()
