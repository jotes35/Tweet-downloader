

def add():
    x=1
    y=2
    print(x+y)


add()


