# INDEXING STRINGS

mystring='indabaxghana'

#eg. 1 first character in the string
#print(mystring[0])

# eg. 2 last character
#print(mystring[-1])

#eg. 3 obtaining substrings
#substring=mystring[0:5]
#print(substring)

