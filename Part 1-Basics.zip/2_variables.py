x=2
print(x)
