
#this returns a value from a function
def add():
    x=1
    y=2
    return(x+y)


result=add()
print(result)


