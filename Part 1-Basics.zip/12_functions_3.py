
#function with arguments
def add(a,b):
    c=a+b
    print(c)


add(1,3)
add(5,7)



