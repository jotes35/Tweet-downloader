#eg.1
#mystring='Python programming'
#print(mystring)


#eg.2
#mynumber='123'
#print(mynumber)

