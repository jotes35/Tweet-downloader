
# function y=mx+c


def compute(m,x,c):
    y=(m*x)+c
    return(y)


y=compute(1,2,3)
print(y)




