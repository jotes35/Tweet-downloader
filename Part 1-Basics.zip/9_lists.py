#lists

numbers=[1,2,3]
print(numbers)

hashtags=['indabaxgh','ghdatascience']
print(hashtags)

data_science=['machine learning','mathematics','business analytics']
print(data_science)
print(data_science[1])

