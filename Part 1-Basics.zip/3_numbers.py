#num=3
#print(num)


#print(num+5)
#print(num/2)

#print(float(3))
#print(2.0)

#print(float(num)/2)
